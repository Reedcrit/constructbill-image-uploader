# ConstructBill Image Uploader Extension

This Chrome extension allows you to easily capture and send images to the ConstructBill application for use in proposals and other documents.

## Features

- Upload images from your computer
- Drag and drop image files
- Capture screenshots of the current tab
- Send any image from any website using the right-click context menu
- Works with the ConstructBill application to enhance your workflow

## Installation Instructions

1. Download and extract the extension zip file
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" using the toggle in the top-right corner
4. Click "Load unpacked" and select the extracted extension folder
5. The extension icon will appear in your Chrome toolbar

## How to Use

### From the Extension Popup

1. Click the ConstructBill extension icon in your toolbar
2. Upload an image using one of these methods:
   - Click the drop area to select a file from your computer
   - Drag and drop an image file onto the drop area
   - Click "Capture Visible Tab" to take a screenshot
3. Click "Send to ConstructBill" to send the image to the application

### From Any Website (Context Menu)

1. Right-click on any image on any website
2. Select "Send to ConstructBill" from the context menu
3. The image will be sent to your open ConstructBill tab

### Requirements

- Make sure you have the ConstructBill application open in a browser tab
- You need to be on a page that can accept images (like the proposal editor)

## Troubleshooting

- If the extension can't find a ConstructBill page, open the application first
- If images aren't appearing in ConstructBill, refresh the page and try again

## Privacy & Data

This extension only sends images to your own ConstructBill application. No data is sent to any third-party servers or services.

## Contact

For support, please contact your ConstructBill administrator.