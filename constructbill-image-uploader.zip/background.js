// This script runs in the background and manages extension behavior

// Initialize context menu when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  // Create a context menu item for images
  chrome.contextMenus.create({
    id: "sendToConstructBill",
    title: "Send to ConstructBill",
    contexts: ["image"]
  });
  
  console.log("ConstructBill Image Uploader installed - context menu created");
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "sendToConstructBill") {
    console.log("Context menu clicked for image:", info.srcUrl);
    
    // Send the image URL to the content script
    chrome.tabs.sendMessage(tab.id, {
      action: "sendImage",
      imageData: info.srcUrl
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Error sending image:", chrome.runtime.lastError);
      } else if (response && response.success) {
        console.log("Image sent successfully via context menu");
      }
    });
  }
});

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "contentScriptLoaded") {
    console.log("Content script loaded on:", message.url);
  }
});