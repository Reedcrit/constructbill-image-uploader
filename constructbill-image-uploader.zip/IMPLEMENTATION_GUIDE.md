# ConstructBill Chrome Extension - Implementation Guide

This guide explains how to integrate the ConstructBill Image Uploader Chrome extension with your application.

## How the Extension Works

1. The extension injects a content script into all web pages
2. When an image is selected through the extension, it uses `window.postMessage` to send image data
3. Your application listens for these messages and processes the images

## Integration Steps

### 1. Add a Message Event Listener to Your Image Uploader Component

Add this JavaScript code to your component that handles image uploads:

```javascript
// Listen for messages from the Chrome extension
useEffect(() => {
  const handleExtensionMessage = (event) => {
    // Verify the message is from our extension
    if (event.data && event.data.type === 'FROM_EXTENSION' && event.data.imageData) {
      console.log('Received image data from Chrome extension');
      
      // Process the image data - this might be a URL or base64 data
      const imageData = event.data.imageData;
      
      // Handle the image similar to how you'd handle a file upload
      if (imageData.startsWith('data:')) {
        // It's a base64 image
        handleImageDataUri(imageData);
      } else {
        // It's a URL, fetch the image
        fetchImageFromUrl(imageData);
      }
    }
  };

  // Add the event listener
  window.addEventListener('message', handleExtensionMessage);
  
  // Clean up when component unmounts
  return () => {
    window.removeEventListener('message', handleExtensionMessage);
  };
}, []);

// Function to handle base64 image data
const handleImageDataUri = (dataUri) => {
  // Convert base64 to a file object if needed
  const byteString = atob(dataUri.split(',')[1]);
  const mimeString = dataUri.split(',')[0].split(':')[1].split(';')[0];
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  
  const blob = new Blob([ab], { type: mimeString });
  const file = new File([blob], "image-from-extension." + mimeString.split('/')[1], { type: mimeString });
  
  // Now use your existing upload handler with this file
  uploadHandler(file);
};

// Function to fetch an image from a URL
const fetchImageFromUrl = async (url) => {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const filename = url.split('/').pop() || 'image-from-extension.jpg';
    const file = new File([blob], filename, { type: blob.type });
    
    // Now use your existing upload handler with this file
    uploadHandler(file);
  } catch (error) {
    console.error('Error fetching image from URL:', error);
  }
};
```

### 2. Testing the Integration

1. Open your application in Chrome
2. Navigate to a page where image uploads are handled
3. Use the Chrome extension to select or capture an image
4. Verify that the image appears in your application

### 3. Troubleshooting

If the extension isn't working:

1. **Check Console Logs**: Open Chrome DevTools and look for messages in the console
2. **Check Content Security Policy**: Your site might block postMessage events; ensure your CSP allows them
3. **Verify Origin**: The extension works on any site, but you might want to restrict message processing to specific pages

### 4. Security Considerations

- Always validate image data received from the extension
- Implement size limits and file type validation
- Consider adding a verification mechanism to ensure messages only come from your extension

## Example Implementation for ConstructBill

Here's how to integrate with the existing ImageUploader component:

```jsx
// In your ImageUploader.jsx or similar component
import { useEffect } from 'react';

function ImageUploader() {
  // Your existing component code...
  
  // Add this useEffect to listen for extension messages
  useEffect(() => {
    const handleExtensionMessage = (event) => {
      if (event.data && event.data.type === 'FROM_EXTENSION' && event.data.imageData) {
        console.log('Received image from Chrome extension');
        // Use your existing image handling logic
        handleImageReceived(event.data.imageData);
      }
    };

    window.addEventListener('message', handleExtensionMessage);
    return () => window.removeEventListener('message', handleExtensionMessage);
  }, []);
  
  const handleImageReceived = (imageData) => {
    // Integrate with your existing image handling code
    // This might involve updating state, uploading to a server, etc.
  };
  
  // Rest of your component...
}

export default ImageUploader;
```

## Need Help?

If you encounter issues integrating the extension:
- Review the Chrome extension documentation
- Check the console logs in both your application and the extension
- Ensure your web application is properly set up to receive postMessage events