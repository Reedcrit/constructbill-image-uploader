// This script runs on the webpage and communicates with the extension

// Listen for messages from the extension's popup or background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("Content script received message:", request);
  
  if (request.action === "sendImage" && request.imageData) {
    // Send the image data to the page using window.postMessage
    window.postMessage({
      type: 'FROM_EXTENSION',
      imageData: request.imageData
    }, '*');
    
    // Let the extension know it worked
    sendResponse({success: true, message: "Image sent to page successfully"});
    
    // Also log for debugging
    console.log("Image data sent to page from extension");
  } else if (request.action === "checkPage") {
    // Check if we're on a ConstructBill page that can accept images
    // This is a simple check - in a real extension you might look for specific elements
    const isConstructBillPage = window.location.href.includes("proposals") || 
                               document.title.includes("ConstructBill");
    
    sendResponse({
      isConstructBillPage: isConstructBillPage
    });
  }
  
  // Return true to indicate we'll send a response asynchronously
  return true;
});

// Let the extension know that the content script is loaded
chrome.runtime.sendMessage({
  action: "contentScriptLoaded",
  url: window.location.href
});

// Log for debugging when content script loads
console.log("ConstructBill Image Uploader content script loaded");